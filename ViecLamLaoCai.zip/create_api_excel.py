#!/usr/bin/env python3
# -*- coding: utf-8 -*-

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    print("✅ Openpyxl available - creating styled Excel")
    USE_OPENPYXL = True
except ImportError:
    print("⚠️ Openpyxl not available - creating basic CSV")
    USE_OPENPYXL = False
    import csv

if USE_OPENPYXL:
    # Tạo workbook mới
    wb = Workbook()
    wb.remove(wb.active)  # Xóa sheet mặc định

    # Định nghĩa style
    header_font = Font(bold=True, color='FFFFFF')
    header_fill = PatternFill(start_color='366092', end_color='366092', fill_type='solid')
    border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )

# Data cho từng sheet
sheets_data = {
    'HOME PAGE APIs': [
        [1, 'GET /api/home/featured-jobs', 'GET', 'Lấy danh sách việc làm nổi bật', '{"isSuccess": true, "statusCode": 200, "message": "Success", "result": [{"id": 1, "title": "Frontend Developer", "company": "ABC Company", "logo": "/images/abc.png", "salary": "15-25 triệu", "location": "Lào Cai", "urgent": true}]}'],
        [2, 'GET /api/home/suggested-jobs', 'GET', 'Lấy danh sách việc làm gợi ý theo user', '{"isSuccess": true, "statusCode": 200, "message": "Success", "result": [{"id": 2, "title": "Backend Developer", "company": "XYZ Corp", "matchScore": 85}]}'],
        [3, 'GET /api/home/job-categories', 'GET', 'Lấy danh sách ngành nghề nổi bật', '{"isSuccess": true, "statusCode": 200, "message": "Success", "result": [{"id": 1, "name": "Công nghệ thông tin", "jobCount": 245}]}'],
        [4, 'GET /api/home/statistics', 'GET', 'Lấy thống kê tổng quan trang chủ', '{"isSuccess": true, "statusCode": 200, "message": "Success", "result": {"totalJobs": 1250, "totalCompanies": 350}}'],
        [5, 'GET /api/home/popular-searches', 'GET', 'Lấy từ khóa tìm kiếm phổ biến', '{"isSuccess": true, "statusCode": 200, "message": "Success", "result": ["Frontend Developer", "Kế toán"]}'],
        [6, 'POST /api/home/search', 'POST', 'Tìm kiếm việc làm từ trang chủ', '{"isSuccess": true, "statusCode": 200, "message": "Success", "result": {"jobs": [...], "totalCount": 45}}']
    ],
    'JOB MANAGEMENT APIs': [
        [1, 'GET /api/jobs', 'GET', 'Lấy danh sách tất cả việc làm', '{"isSuccess": true, "statusCode": 200, "result": {"jobs": [...], "pagination": {...}}}'],
        [2, 'GET /api/jobs/{id}', 'GET', 'Lấy chi tiết một việc làm', '{"isSuccess": true, "statusCode": 200, "result": {"id": 1, "title": "Frontend Developer"}}'],
        [3, 'POST /api/jobs', 'POST', 'Tạo việc làm mới', '{"isSuccess": true, "statusCode": 201, "message": "Job created successfully", "result": {"id": 123}}'],
        [4, 'PUT /api/jobs/{id}', 'PUT', 'Cập nhật thông tin việc làm', '{"isSuccess": true, "statusCode": 200, "message": "Job updated successfully"}'],
        [5, 'DELETE /api/jobs/{id}', 'DELETE', 'Xóa việc làm', '{"isSuccess": true, "statusCode": 200, "message": "Job deleted successfully"}'],
        [6, 'GET /api/jobs/search', 'GET', 'Tìm kiếm việc làm với bộ lọc', '{"isSuccess": true, "statusCode": 200, "result": {"jobs": [...], "totalCount": 45}}'],
        [7, 'POST /api/jobs/{id}/apply', 'POST', 'Ứng tuyển vào việc làm', '{"isSuccess": true, "statusCode": 200, "message": "Application submitted successfully"}'],
        [8, 'POST /api/jobs/{id}/save', 'POST', 'Lưu việc làm yêu thích', '{"isSuccess": true, "statusCode": 200, "message": "Job saved successfully"}'],
        [9, 'DELETE /api/jobs/{id}/save', 'DELETE', 'Bỏ lưu việc làm', '{"isSuccess": true, "statusCode": 200, "message": "Job unsaved successfully"}'],
        [10, 'GET /api/jobs/categories', 'GET', 'Lấy danh sách ngành nghề', '{"isSuccess": true, "statusCode": 200, "result": [{"id": 1, "name": "Công nghệ thông tin"}]}']
    ],
    'CANDIDATE MANAGEMENT APIs': [
        [1, 'GET /api/candidates', 'GET', 'Lấy danh sách ứng viên', '{"isSuccess": true, "statusCode": 200, "result": {"candidates": [...], "pagination": {...}}}'],
        [2, 'GET /api/candidates/{id}', 'GET', 'Lấy thông tin chi tiết ứng viên', '{"isSuccess": true, "statusCode": 200, "result": {"id": 1, "fullName": "Nguyễn Văn A"}}'],
        [3, 'POST /api/candidates', 'POST', 'Tạo hồ sơ ứng viên mới', '{"isSuccess": true, "statusCode": 201, "message": "Candidate created successfully"}'],
        [4, 'PUT /api/candidates/{id}', 'PUT', 'Cập nhật thông tin ứng viên', '{"isSuccess": true, "statusCode": 200, "message": "Candidate updated successfully"}'],
        [5, 'DELETE /api/candidates/{id}', 'DELETE', 'Xóa hồ sơ ứng viên', '{"isSuccess": true, "statusCode": 200, "message": "Candidate deleted successfully"}'],
        [6, 'GET /api/candidates/search', 'GET', 'Tìm kiếm ứng viên', '{"isSuccess": true, "statusCode": 200, "result": {"candidates": [...], "totalCount": 25}}'],
        [7, 'GET /api/candidates/{id}/applications', 'GET', 'Lấy danh sách đơn ứng tuyển của ứng viên', '{"isSuccess": true, "statusCode": 200, "result": [{"id": 1, "jobTitle": "...", "status": "pending"}]}'],
        [8, 'GET /api/candidates/{id}/saved-jobs', 'GET', 'Lấy danh sách việc làm đã lưu', '{"isSuccess": true, "statusCode": 200, "result": [{"id": 1, "jobTitle": "..."}]}'],
        [9, 'POST /api/candidates/{id}/upload-cv', 'POST', 'Upload CV cho ứng viên', '{"isSuccess": true, "statusCode": 200, "message": "CV uploaded successfully"}'],
        [10, 'GET /api/candidates/{id}/statistics', 'GET', 'Thống kê hoạt động của ứng viên', '{"isSuccess": true, "statusCode": 200, "result": {"profileViews": 45, "applications": 12}}']
    ],
    'BUSINESS APPROVAL APIs': [
        [1, 'GET /api/business-approval', 'GET', 'Lấy danh sách doanh nghiệp cần phê duyệt', '{"isSuccess": true, "statusCode": 200, "result": [{"id": 1, "businessName": "Công ty ABC", "status": "pending"}]}'],
        [2, 'GET /api/business-approval/{id}', 'GET', 'Lấy chi tiết doanh nghiệp cần phê duyệt', '{"isSuccess": true, "statusCode": 200, "result": {"id": 1, "businessName": "...", "documents": [...]}}'],
        [3, 'POST /api/business-approval/{id}/approve', 'POST', 'Phê duyệt doanh nghiệp', '{"isSuccess": true, "statusCode": 200, "message": "Business approved successfully"}'],
        [4, 'POST /api/business-approval/{id}/reject', 'POST', 'Từ chối phê duyệt doanh nghiệp', '{"isSuccess": true, "statusCode": 200, "message": "Business rejected successfully"}'],
        [5, 'POST /api/business-approval/{id}/review', 'POST', 'Đánh dấu đang xem xét', '{"isSuccess": true, "statusCode": 200, "message": "Business marked for review"}'],
        [6, 'GET /api/business-approval/statistics', 'GET', 'Thống kê phê duyệt doanh nghiệp', '{"isSuccess": true, "statusCode": 200, "result": {"pending": 25, "approved": 150}}'],
        [7, 'GET /api/business-approval/export', 'GET', 'Xuất báo cáo danh sách doanh nghiệp', '{"isSuccess": true, "statusCode": 200, "result": {"downloadUrl": "/exports/business-report.xlsx"}}']
    ],
    'STATISTICS & REPORTING APIs': [
        [1, 'GET /api/statistics/overview', 'GET', 'Thống kê tổng quan hệ thống', '{"isSuccess": true, "statusCode": 200, "result": {"totalJobs": 1250, "activeJobs": 890}}'],
        [2, 'GET /api/statistics/business-trends', 'GET', 'Xu hướng đăng ký doanh nghiệp', '{"isSuccess": true, "statusCode": 200, "result": [{"month": "2024-01", "registrations": 45}]}'],
        [3, 'GET /api/statistics/search-keywords', 'GET', 'Từ khóa tìm kiếm phổ biến', '{"isSuccess": true, "statusCode": 200, "result": [{"keyword": "frontend developer", "searchCount": 245}]}'],
        [4, 'GET /api/statistics/job-applications', 'GET', 'Thống kê đơn ứng tuyển', '{"isSuccess": true, "statusCode": 200, "result": [{"date": "2024-01-15", "applications": 125}]}'],
        [5, 'GET /api/statistics/industry-breakdown', 'GET', 'Phân tích theo ngành nghề', '{"isSuccess": true, "statusCode": 200, "result": [{"industry": "Công nghệ thông tin", "jobCount": 345}]}'],
        [6, 'POST /api/statistics/export', 'POST', 'Xuất báo cáo thống kê', '{"isSuccess": true, "statusCode": 200, "result": {"downloadUrl": "/exports/statistics-report.xlsx"}}'],
        [7, 'GET /api/statistics/dashboard', 'GET', 'Dữ liệu cho dashboard admin', '{"isSuccess": true, "statusCode": 200, "result": {"todayStats": {...}, "weeklyTrends": [...]}}']
    ],
    'LABOR MARKET REPORT APIs': [
        [1, 'GET /api/labor-market/overview', 'GET', 'Tổng quan thị trường lao động', '{"isSuccess": true, "statusCode": 200, "result": {"totalDemand": 2500, "totalSupply": 1800}}'],
        [2, 'GET /api/labor-market/job-trends', 'GET', 'Xu hướng việc làm theo thời gian', '{"isSuccess": true, "statusCode": 200, "result": [{"month": "2024-01", "demand": 250}]}'],
        [3, 'GET /api/labor-market/skill-demands', 'GET', 'Nhu cầu kỹ năng trên thị trường', '{"isSuccess": true, "statusCode": 200, "result": [{"skill": "React", "demandCount": 145}]}'],
        [4, 'GET /api/labor-market/salary-ranges', 'GET', 'Phân tích mức lương theo vị trí', '{"isSuccess": true, "statusCode": 200, "result": [{"position": "Frontend Developer", "averageSalary": 18.5}]}'],
        [5, 'GET /api/labor-market/insights', 'GET', 'Thông tin chi tiết thị trường', '{"isSuccess": true, "statusCode": 200, "result": [{"title": "Xu hướng remote work", "impact": "positive"}]}'],
        [6, 'POST /api/labor-market/export', 'POST', 'Xuất báo cáo thị trường lao động', '{"isSuccess": true, "statusCode": 200, "result": {"downloadUrl": "/exports/labor-market-report.xlsx"}}'],
        [7, 'GET /api/labor-market/predictions', 'GET', 'Dự báo thị trường lao động', '{"isSuccess": true, "statusCode": 200, "result": [{"period": "Q2-2024", "predictedDemand": 2800}]}']
    ],
    'APPLICATION MANAGEMENT APIs': [
        [1, 'GET /api/applications', 'GET', 'Lấy danh sách đơn ứng tuyển', '{"isSuccess": true, "statusCode": 200, "result": {"applications": [...], "pagination": {...}}}'],
        [2, 'GET /api/applications/{id}', 'GET', 'Chi tiết đơn ứng tuyển', '{"isSuccess": true, "statusCode": 200, "result": {"id": 1, "candidateId": 123, "status": "pending"}}'],
        [3, 'PUT /api/applications/{id}/status', 'PUT', 'Cập nhật trạng thái đơn ứng tuyển', '{"isSuccess": true, "statusCode": 200, "message": "Application status updated"}'],
        [4, 'GET /api/applications/candidate/{candidateId}', 'GET', 'Đơn ứng tuyển của ứng viên cụ thể', '{"isSuccess": true, "statusCode": 200, "result": [{"id": 1, "jobTitle": "...", "status": "pending"}]}'],
        [5, 'GET /api/applications/job/{jobId}', 'GET', 'Đơn ứng tuyển cho công việc cụ thể', '{"isSuccess": true, "statusCode": 200, "result": [{"id": 1, "candidateName": "...", "matchScore": 85}]}'],
        [6, 'DELETE /api/applications/{id}', 'DELETE', 'Xóa/Thu hồi đơn ứng tuyển', '{"isSuccess": true, "statusCode": 200, "message": "Application withdrawn successfully"}'],
        [7, 'GET /api/applications/statistics', 'GET', 'Thống kê đơn ứng tuyển', '{"isSuccess": true, "statusCode": 200, "result": {"total": 1250, "pending": 450, "accepted": 300}}']
    ],
    'DASHBOARD APIs': [
        [1, 'GET /api/dashboard/overview', 'GET', 'Tổng quan dashboard chính', '{"isSuccess": true, "statusCode": 200, "result": {"quickStats": {...}, "recentActivities": [...]}}'],
        [2, 'GET /api/dashboard/notifications', 'GET', 'Thông báo cho dashboard', '{"isSuccess": true, "statusCode": 200, "result": [{"id": 1, "type": "info", "title": "Có đơn ứng tuyển mới"}]}'],
        [3, 'PUT /api/dashboard/notifications/{id}/read', 'PUT', 'Đánh dấu đã đọc thông báo', '{"isSuccess": true, "statusCode": 200, "message": "Notification marked as read"}'],
        [4, 'GET /api/dashboard/activities', 'GET', 'Hoạt động gần đây', '{"isSuccess": true, "statusCode": 200, "result": [{"id": 1, "type": "application", "description": "..."}]}'],
        [5, 'GET /api/dashboard/quick-stats', 'GET', 'Thống kê nhanh cho dashboard', '{"isSuccess": true, "statusCode": 200, "result": {"todayApplications": 25, "pendingApprovals": 12}}'],
        [6, 'POST /api/dashboard/refresh', 'POST', 'Làm mới dữ liệu dashboard', '{"isSuccess": true, "statusCode": 200, "message": "Dashboard data refreshed successfully"}']
    ],
    'AUTHENTICATION & USER APIs': [
        [1, 'POST /api/auth/login', 'POST', 'Đăng nhập hệ thống', '{"isSuccess": true, "statusCode": 200, "message": "Login successful", "result": {"token": "jwt_token_here"}}'],
        [2, 'POST /api/auth/logout', 'POST', 'Đăng xuất hệ thống', '{"isSuccess": true, "statusCode": 200, "message": "Logout successful"}'],
        [3, 'POST /api/auth/refresh-token', 'POST', 'Làm mới token', '{"isSuccess": true, "statusCode": 200, "result": {"token": "new_jwt_token"}}'],
        [4, 'POST /api/auth/register', 'POST', 'Đăng ký tài khoản mới', '{"isSuccess": true, "statusCode": 201, "message": "Registration successful", "result": {"userId": 123}}'],
        [5, 'POST /api/auth/forgot-password', 'POST', 'Quên mật khẩu', '{"isSuccess": true, "statusCode": 200, "message": "Password reset email sent"}'],
        [6, 'POST /api/auth/reset-password', 'POST', 'Đặt lại mật khẩu', '{"isSuccess": true, "statusCode": 200, "message": "Password reset successful"}'],
        [7, 'GET /api/auth/profile', 'GET', 'Lấy thông tin profile người dùng', '{"isSuccess": true, "statusCode": 200, "result": {"id": 123, "email": "...", "fullName": "..."}}'],
        [8, 'PUT /api/auth/profile', 'PUT', 'Cập nhật thông tin profile', '{"isSuccess": true, "statusCode": 200, "message": "Profile updated successfully"}']
    ],
    'SEARCH & FILTER APIs': [
        [1, 'GET /api/search/jobs', 'GET', 'Tìm kiếm việc làm với filter', '{"isSuccess": true, "statusCode": 200, "result": {"jobs": [...], "totalCount": 45, "appliedFilters": {...}}}'],
        [2, 'GET /api/search/candidates', 'GET', 'Tìm kiếm ứng viên', '{"isSuccess": true, "statusCode": 200, "result": {"candidates": [...], "totalCount": 25}}'],
        [3, 'GET /api/search/companies', 'GET', 'Tìm kiếm công ty', '{"isSuccess": true, "statusCode": 200, "result": {"companies": [...], "totalCount": 15}}'],
        [4, 'GET /api/search/suggestions', 'GET', 'Gợi ý tìm kiếm', '{"isSuccess": true, "statusCode": 200, "result": ["Developer", "Development", "Frontend Developer"]}'],
        [5, 'POST /api/search/save-search', 'POST', 'Lưu tìm kiếm', '{"isSuccess": true, "statusCode": 200, "message": "Search saved successfully", "result": {"searchId": 456}}'],
        [6, 'GET /api/search/saved-searches', 'GET', 'Lấy danh sách tìm kiếm đã lưu', '{"isSuccess": true, "statusCode": 200, "result": [{"id": 456, "searchQuery": "developer", "filters": {...}}]}']
    ]
}

if USE_OPENPYXL:
    # Tạo từng sheet với openpyxl
    for sheet_name, data in sheets_data.items():
        ws = wb.create_sheet(title=sheet_name)
        
        # Header
        headers = ['STT', 'Tên API', 'Method', 'Mục đích', 'Ví dụ JSON trả ra']
        ws.append(headers)
        
        # Style header
        for cell in ws[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = border
        
        # Add data
        for row_data in data:
            ws.append(row_data)
        
        # Style data cells
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.border = border
                cell.alignment = Alignment(vertical='top', wrap_text=True)
        
        # Set column widths
        column_widths = [5, 40, 10, 50, 80]  # STT, Tên API, Method, Mục đích, JSON
        for i, width in enumerate(column_widths, 1):
            ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = width
        
        # Set row height for header
        ws.row_dimensions[1].height = 25

    # Lưu file Excel
    wb.save('API_COMPREHENSIVE_LIST_FOR_BACKEND.xlsx')
    print('✅ Đã tạo file Excel: API_COMPREHENSIVE_LIST_FOR_BACKEND.xlsx')
else:
    # Tạo CSV files thay thế
    import os
    if not os.path.exists('API_CSV_FILES'):
        os.makedirs('API_CSV_FILES')
    
    for sheet_name, data in sheets_data.items():
        filename = f'API_CSV_FILES/{sheet_name.replace(" ", "_").replace("/", "_")}.csv'
        with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            # Header
            writer.writerow(['STT', 'Tên API', 'Method', 'Mục đích', 'Ví dụ JSON trả ra'])
            # Data
            for row_data in data:
                writer.writerow(row_data)
        print(f'✅ Đã tạo file CSV: {filename}')

print(f'📊 Tổng cộng: {len(sheets_data)} sheets với {sum(len(data) for data in sheets_data.values())} APIs')






